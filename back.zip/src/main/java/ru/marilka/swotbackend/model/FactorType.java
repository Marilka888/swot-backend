package ru.marilka.swotbackend.model;

public enum FactorType {
    STRONG,
    WEAK,
    OPPORTUNITY,
    THREAT
}
