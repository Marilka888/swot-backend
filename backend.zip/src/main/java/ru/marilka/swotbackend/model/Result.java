package ru.marilka.swotbackend.model;

public record Result(String description, double score) {
}