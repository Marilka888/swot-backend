package ru.marilka.swotbackend.model.request;

public record ParticipantDto(
        Long userId,
        double coefficient
) {}
